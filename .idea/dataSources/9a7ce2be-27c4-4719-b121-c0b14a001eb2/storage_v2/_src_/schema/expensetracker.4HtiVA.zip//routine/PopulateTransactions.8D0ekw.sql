create
    definer = expense_user@localhost procedure PopulateTransactions()
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE v_User_ID, v_Account_ID, v_Category_ID, v_PaymentMethod_ID INT;
    DECLARE v_Quantity INT;
    DECLARE v_Price DECIMAL(10,2);

    WHILE i < 200 DO
            SELECT User_ID INTO v_User_ID FROM users ORDER BY RAND() LIMIT 1;
            SELECT Account_ID INTO v_Account_ID FROM accounts WHERE User_ID = v_User_ID ORDER BY RAND() LIMIT 1;

            IF v_Account_ID IS NOT NULL THEN
                SELECT Category_ID INTO v_Category_ID FROM categories ORDER BY RAND() LIMIT 1;
                SET v_PaymentMethod_ID = FLOOR(1 + (RAND() * 10));
                SET v_Quantity = FLOOR(1 + (RAND() * 5));
                SET v_Price = ROUND(RAND() * 100 + 1, 2);

                INSERT INTO Transactions (User_ID, Account_ID, Category_ID, PaymentMethod_ID, Quantity, Price, Transaction_Date, Description)
                VALUES (v_User_ID, v_Account_ID, v_Category_ID, v_PaymentMethod_ID, v_Quantity, v_Price, NOW(), CONCAT('Auto-generated transaction #', i+1));

                SET i = i + 1;
            END IF;
        END WHILE;
END;

