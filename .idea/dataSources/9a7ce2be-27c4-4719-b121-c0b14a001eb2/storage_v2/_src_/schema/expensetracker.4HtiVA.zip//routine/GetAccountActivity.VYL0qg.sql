create
    definer = expense_user@localhost procedure GetAccountActivity(IN selected_user int, IN selected_account int,
                                                                  IN start_date date, IN end_date date)
BEGIN
    SELECT T.User_ID, T.Account_ID, T.Transaction_Date, T.Description, C.Category_Name, P.Method_Name, T.Amount, A.Balance AS Updated_Balance
    FROM Transactions T
             JOIN Categories C ON T.Category_ID = C.Category_ID
             JOIN PaymentMethod P ON T.PaymentMethod_ID = P.PaymentMethod_ID
             JOIN Accounts A ON T.Account_ID = A.Account_ID
    WHERE T.Transaction_Date BETWEEN start_date AND end_date
      AND (selected_user IS NULL OR T.User_ID = selected_user)
      AND (selected_account IS NULL OR T.Account_ID = selected_account)
    ORDER BY T.Transaction_Date ASC;
END;

